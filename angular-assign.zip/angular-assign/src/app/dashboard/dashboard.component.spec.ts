import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DashboardComponent } from './dashboard.component';
import { ProviderAst } from '@angular/compiler';
import { StudentgradesService } from '../studentgrades.service';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Router, RouterModule, RoutesRecognized } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { routes } from '../app-routing.module';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Observable,of } from 'rxjs';

describe('DashboardComponent', () => {
  let component: DashboardComponent;
  let fixture: ComponentFixture<DashboardComponent>;
  let studentservice: StudentgradesService
  let spy: any; 
  let router:Router
  // let Servicespy: { getstudentdata: jasmine.Spy };
  const mockedstudService = jasmine.createSpyObj('studentservice', ['getstudentdata']);
  let mockSomeService = {
    getstudentdata: () =>{ return of()}
  }

  let mockRouter = {
    navigate: jasmine.createSpy('navigate')
  }
  beforeEach(async () => {
    
    await TestBed.configureTestingModule({
      declarations: [ DashboardComponent ],
      providers:[{ provide : StudentgradesService, useValue : mockSomeService},HttpClient,{ provide: Router, useValue: mockRouter}],
      imports:[HttpClientTestingModule,RouterTestingModule.withRoutes(routes)]
    })
    .compileComponents();
   
   // Servicespy = jasmine.createSpyObj('service', ['getstudentdata']);
    // router = TestBed.inject(Router);
    // router.initialNavigation();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should have been called the service', () => {
    spyOn(mockSomeService, 'getstudentdata').and.returnValue(of({}))
    component.getfilteredata()
    expect(mockSomeService.getstudentdata).toHaveBeenCalledTimes(1);
  });  

  // it("should navigate",()=>{    
  //   expect (mockRouter.navigate).toHaveBeenCalledWith (['/section']);
  // })
});
