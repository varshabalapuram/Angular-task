import { Component, OnInit } from '@angular/core';
import { StudentgradesService } from '../studentgrades.service';
import { Sectiontype } from '../model/student-table';
import { Router } from '@angular/router';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  data: any;
  options: any;
  filtered:Sectiontype;
  studentdata:any;
 
  constructor(private service:StudentgradesService,private router: Router) {
        this.filtered=new Sectiontype()     
}
  ngOnInit() {
    this.getfilteredata()   
  }
    
  
  getfilteredata(){
    this.service.getstudentdata().subscribe((data:any)=>{
      console.log(data)
      this.studentdata=data; 
      if(this.studentdata){  
            let percentage=0;
            this.studentdata.forEach((element:any) => {
                  percentage=((parseInt(element.english)+parseInt(element.maths)+parseInt(element.science)+parseInt(element.social))/400*100);
                  if(percentage >= 90){
                      this.filtered.firstgrade.push(element)
                  }
                  else if(percentage >= 70 && percentage < 90){
                    this.filtered.secondgrade.push(element)
                  }
                  else{
                    this.filtered.thirdgrade.push(element)
                  }
            })
           
            console.log(this.filtered.thirdgradelength)
            this.data = {
              labels: ['grade 1', 'Grade2', 'grade3'],
              datasets: [
                  {
                      label: 'First Dataset',
                      data: [this.filtered.firstgrade.length, this.filtered.secondgrade.length, this.filtered.thirdgrade.length],
                      backgroundColor: [
                        "#42A5F5",
                        "#66BB6A",
                        "#FFA726"
                    ],
                  },
                
              ]
          }
          this.options = {
              title: {
                  display: true,
                  text: 'My Title',
                  fontSize: 16
              },
              legend: {
                  position: 'bottom'
              }
          };

        }
        //console.log(this.studentdata)
      })
     
    
    
    
     
  }

  selectData(event:any) {
    console.log(event)
    this.router.navigate(["/section",event.element.index])
}
     

}
