export class Student{
    id?:number;
    name?:String;
    age?:Number;
    email?:String;
    english?:Number;
    maths?:Number;
    science?:Number;
    social?:Number;
}

export class Sectiontype{
    firstgrade:Student[]=[];
    secondgrade:Student[]=[];
    thirdgrade:Student[]=[];
    firstgradelength:Number=0;
    secondgradelength:Number=0;
    thirdgradelength:Number=0;
}
