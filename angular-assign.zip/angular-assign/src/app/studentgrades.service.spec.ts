import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { StudentgradesService } from './studentgrades.service';
import { Student } from './model/student-table';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

const studData:any[] =
[
  {
    "id": 1,
    "name": "john",
    "age": "30",
    "email": "Chaitanya@gmail.com",
    "english": 90,
    "maths": 80,
    "science": 90,
    "social": 100
  },
  {
    "id": 2,
    "name": "Steve",
    "age": "28",
    "email": "Steve@gmail.com",
    "english": "89",
    "maths": "70",
    "science": "90",
    "social": "79"
  },
  {
    "id": 3,
    "name": "Peter",
    "age": "32",
    "email": "Peter",
    "english": "30",
    "maths": "30",
    "science": "30",
    "social": "30"
  },
  {
    "id": 4,
    "name": "Chaitanya",
    "age": "28",
    "email": "Chaitanya@gmail.com",
    "english": 40,
    "maths": 50,
    "science": 40,
    "social": 35
  }
]

describe('StudentgradesService', () => {
  let service: StudentgradesService;
  let httpClientSpy: { get: jasmine.Spy, put: jasmine.Spy };

  beforeEach(() => {
    TestBed.configureTestingModule({
      providers:  [StudentgradesService, HttpTestingController ],
      imports: [HttpClientTestingModule]
      
    });
    service = TestBed.inject(StudentgradesService);

    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get', 'put']);
    service = new StudentgradesService(httpClientSpy as any);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return an Observable<any[]> to get student data from server',   ( done:DoneFn ) => {

    httpClientSpy.get.and.returnValue(of(studData));

    service.getstudentdata().subscribe(
      (resData) => {
        expect(resData).toEqual(studData);
        done();
      },
      done.fail
    );

    expect(httpClientSpy.get.calls.count()).toBe(1);

  });

  it('should perform put operation to update selected student data on server',   ( done ) => {

    let obj:any = { "id": 2,
    "name": "Steve",
    "age": "97",
    "email": "Steve@gmail.com",
    "english": "19",
    "maths": "40",
    "science": "90",
    "social": "79"  };
    httpClientSpy.put.and.returnValue(of(obj));

    service.updatestudentdata(obj).subscribe(
      (resData:any) => {
        expect(resData).toEqual(obj);
        done();
      },
      done.fail
    );

    expect(httpClientSpy.put.calls.count()).toBe(1);

  });

});
