import { ComponentFixture, TestBed, tick } from '@angular/core/testing';

import { SectionComponent } from './section.component';
import { FormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { routes } from '../app-routing.module';
import { StudentgradesService } from '../studentgrades.service';
import { ActivatedRoute } from '@angular/router';
import { By } from '@angular/platform-browser';
import { of } from 'rxjs';
import { Student } from '../model/student-table';

describe('SectionComponent', () => {
  let component: SectionComponent;
  let fixture: ComponentFixture<SectionComponent>;
  let service:StudentgradesService
  const mockedstudService = jasmine.createSpyObj('studentservice', ["getstudentdata",'updatestudentdata']);
  mockedstudService.getstudentdata.and.returnValue(of())


  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SectionComponent ],
      imports :  [FormsModule,HttpClientTestingModule,
        RouterTestingModule.withRoutes(routes)],
      providers:[{ provide : StudentgradesService, useValue : mockedstudService},
        { provide : ActivatedRoute, useValue : {  snapshot : { params : { grade:1 } } }}
      ]
    }).compileComponents();
     service = TestBed.inject(StudentgradesService)
      const activatedRoute = TestBed.inject(ActivatedRoute)
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Testing the functionality of select function',()=>{
     let obj:any = { "id": 2,
    "name": "Steve",
    "age": "97",
    "email": "Steve@gmail.com",
    "english": "19",
    "maths": "40",
    "science": "90",
    "social": "79"  };
      component.select(obj);
      fixture.detectChanges()
      expect(component.editstud).toEqual(obj)
  })

  
  it('Should call the update service',()=>{
    let obj :Student= { "id": 2,
   "name": "Steve",
   "age": 97,
   "email": "Steve@gmail.com",
   "english": 19,
   "maths": 40,
   "science": 90,
   "social": 79  };
   mockedstudService.updatestudentdata.and.returnValue(of(obj))
     component.updatestud(obj);
     fixture.detectChanges()
     expect(service.updatestudentdata).toHaveBeenCalled()
 })
});
