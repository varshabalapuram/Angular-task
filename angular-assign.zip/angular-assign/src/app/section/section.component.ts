import { Component, OnInit } from '@angular/core';
import { Student } from '../model/student-table';
import { ActivatedRoute } from '@angular/router';
import { StudentgradesService } from '../studentgrades.service';
@Component({
  selector: 'app-section',
  templateUrl: './section.component.html',
  styleUrls: ['./section.component.css']
})
export class SectionComponent implements OnInit {
  studentdata: Student[]=[];
  add:boolean=false;
  editstud:Student;
  dataintable:Student[]=[]
  grade:any;
  Pagetitle?:String
  updatedstud?:Student;
  constructor(private route:ActivatedRoute,private service:StudentgradesService) {
    this.editstud=new Student()
   }
  ngOnInit(): void {
    this.grade=parseInt(this.route.snapshot.params.grade)
    this.getfilterdata()
  }
  getfilterdata(){
    this.dataintable=[];
    this.service.getstudentdata().subscribe((data:any)=>{
      this.studentdata=data; 
      console.log(this.studentdata)
      if(this.studentdata){  
            let percentage=0;
            this.studentdata.forEach((element:any) => {
            percentage=((parseInt(element.english)+parseInt(element.maths)+parseInt(element.science)+parseInt(element.social))/400*100);
                if(this.grade==0 && percentage>= 90){
                    this.dataintable.push(element)
                }
                else if(this.grade==1 && (percentage >= 70 && percentage < 90)){
                  this.dataintable.push(element)
                }
                else if(this.grade==2 && (percentage <70)){
                  this.dataintable.push(element)
                }
            })
          }
    })
  }

  updatestud(stud:Student){  
    this.service.updatestudentdata(stud).subscribe((data)=>{
      this.getfilterdata();
    })
  }

  select(prod:any){
    this.editstud={...prod}
  }

}
