import { TestBed, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';
import { routes } from './app-routing.module';
import { Location } from '@angular/common';
import { Router, RouterLinkWithHref, ActivatedRoute } from '@angular/router';
import { By } from '@angular/platform-browser';

let location: Location;
  let router:Router;
  let activatedRoute: ActivatedRoute;
  
describe('AppComponent', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes(routes)
      ],
      declarations: [
        AppComponent
      ],
    }).compileComponents();
    router = TestBed.inject(Router);
    activatedRoute = TestBed.inject(ActivatedRoute);
    location = TestBed.inject(Location);
    router.initialNavigation();

  });

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'student-app'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.title).toEqual('student-app');
  });

 

  it('navigate dashboard should redirects to dashboard Route', fakeAsync(() => {
    router.navigate(["/dashboard"]).then(  () =>
    {
      expect(location.path()).toBe('/dashboard');
      tick(3000);

    });
}));

it('navigate "/section" should redirects to section Route', fakeAsync(() => {
  router.navigate(["/section/1"]).then(  () =>
  {
   // console.log(location.path());
    expect(location.path()).toBe('/section/1');
    tick(3000);
  });
}));
});
