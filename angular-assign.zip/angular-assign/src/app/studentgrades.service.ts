import { Injectable } from '@angular/core';
import { Student, Sectiontype } from './model/student-table'
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class StudentgradesService {
studentdata:Student[]=[];
filtered:Sectiontype;
  constructor(private https: HttpClient) {
    this.filtered=new Sectiontype();
    
   }

   getstudentdata(){
    return this.https.get('http://localhost:3000/students')
   }
    updatestudentdata(stud:Student){
        return this.https.put<any>('http://localhost:3000/students' + '/' + stud.id, stud);
    }
    
  
   
}
