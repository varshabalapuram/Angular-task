describe('My First Test', () => {
    it('Visits the initial project page', () => {
      cy.visit('http://localhost:4200/section/1')
     // cy.contains('type')
     cy.get('button[id="back-button"]').click();
     cy.url().should('include',"http://localhost:4200/dashboard")
    //  cy.url().should('include', '/section/1')
    //  //cy.contains('sandbox app is running!')
    })
    it('Test get Request', () => {
        cy.request('http://localhost:3000/students').then((response) => {
                    expect(response.body).to.have.length(10)
        })
      })
        it('update modal value', () => {
            cy.visit('http://localhost:4200/section/1')
        cy.get('button[id="editbutton"]').first().click();
        cy.get('form').within(() => {
            cy.get('input[id="name"]').clear()
            cy.get('input[id="name"]').type('stevesmith')
            })    
        cy.get('button[id="saveBtn"]').click();
        cy.get('td',{ timeout: 70000 }).first().contains('stevesmith',{ timeout: 70000 })
        })
        it('check email validation', () => {
            cy.visit('http://localhost:4200/section/1')
        cy.get('button[id="editbutton"]').first().click();
        cy.get('form').within(() => {
            cy.get('input[id="email"]').clear()
            cy.get('input[id="email"]').type('stevesmith')
            })    
        cy.get('button[id="saveBtn"]').should('be.disabled');
        })
      
        it('check Score Validation', () => {
            cy.visit('http://localhost:4200/section/1')
        cy.get('button[id="editbutton"]').first().click();
        cy.get('form').within(() => {
            cy.get('input[id="maths"]').clear()
            cy.get('input[id="maths"]').type('-10')
            cy.get('input[id="maths"]').next('span').contains('Enter valid Score')
            })    
        cy.get('button[id="saveBtn"]').should('be.disabled');
        })
  })

//   describe('Click Edit Button', () => {
//     it('Visits the initial project page', () => {
//       cy.visit('http://localhost:4200/section/1')
//      // cy.contains('type')
//      cy.get('button[id="editbutton"]').click();
//      cy.get('form').within(() => {
//         cy.get('input[id="name"]').should('have.value', 'stevesmith')
//  // Only yield inputs within form
//       })    // cy.url().should('include',"http://localhost:4200/dashboard")
//     //  cy.url().should('include', '/section/1')
//     //  //cy.contains('sandbox app is running!')
//     })
//   })

  

  