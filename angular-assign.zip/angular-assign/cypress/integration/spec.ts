describe('My First Test', () => {
  it('Visits the initial project page', () => {
    cy.visit('http://localhost:4200')
   cy.get('p-chart').click();
   cy.url().should('include', '/section/1')
   //cy.contains('sandbox app is running!')
  })

  it('Test get Request', () => {
    cy.request('http://localhost:3000/students').then((response) => {
                expect(response.body).to.have.length(10)
    })
  })
})
